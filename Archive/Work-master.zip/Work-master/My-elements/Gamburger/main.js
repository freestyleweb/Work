document.querySelector('.menu-btn').addEventListener('click', function (e) {
	event.preventDefault;
	this.classList.toggle('menu-btn__active');
});