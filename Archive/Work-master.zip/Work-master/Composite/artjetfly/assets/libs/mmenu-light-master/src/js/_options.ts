export const core: mmOptions = {
    title: 'Menu',
    theme: 'light',
    selected: 'Selected'
};

export const offcanvas: mmOptionsOffcanvas = {
    blockPage: true,
    move: true,
    position: 'left'
};
