(function( $ ) {

	const _PLUGIN_ 	= 'mmenu';
	const _LANG_ 	= 'fa';

	$[ _PLUGIN_ ].i18n({
		'Menu': 'منو'
	}, _LANG_ );

})( jQuery );
