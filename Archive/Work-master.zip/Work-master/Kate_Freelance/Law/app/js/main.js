$(function(){

$('a.header-search__icon').hover(function(){
	$('div.activ-hints').toggleClass('active')
})


});