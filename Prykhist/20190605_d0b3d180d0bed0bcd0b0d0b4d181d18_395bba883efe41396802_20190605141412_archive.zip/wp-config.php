<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', '' );


/** Имя пользователя MySQL */
define( 'DB_USER', '' );


/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );


/** Имя сервера MySQL */
define( 'DB_HOST', '' );


/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );


/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         't|6OlG8m*7p`~0w1kD~;k)1U=rk+/OgN<$&<-IDs9,s>%<r-.#AgDc mu>9d1(#v' );

define( 'SECURE_AUTH_KEY',  '-Yk2F}FUwrHV*)C9Ra9GjB;nWWJD;O.qg3hT(xj,l,!s|Kbu{BO8A5wQOnrk(R36' );

define( 'LOGGED_IN_KEY',    '}bdWh4*(e%ZI7d!k1$IoNa@2`%OC]hYiUONUvb:xsgU9bh+[{oQy+u>]/m04`U3J' );

define( 'NONCE_KEY',        's;&j.fbE<8p3ZC`SxJG<jVnVs_xPLta]JeH#iZBgJ#]o_Ix(yCVd!dC/Kh+j>O6~' );

define( 'AUTH_SALT',        'g61!%t!Ajc?%j7->P>oB!Nw~zuOu3?B<yGZ(lPF#7|n,Tyf=j?8G/Q4}0N/jlqR^' );

define( 'SECURE_AUTH_SALT', 'bh^@09T#qJ}+yGD5~;PE(+!3H)%Q14*|<VCd`@!-Q_le;T(1m1` lC m:HXq{~_G' );

define( 'LOGGED_IN_SALT',   'xT:qG2jeGrn}qE^?Qp&=Sz(E5)w?,li^z*-z9J{DwV]a}M;y*$cjy#7BJQI Zw0w' );

define( 'NONCE_SALT',       'LgC[D7Y{=b0b=B$l=tq0SO$7sc{%]lN~HMDv?Fz]T<1F X)5<@flRRj[$~L}e>OH' );


/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'gopr_';


/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
